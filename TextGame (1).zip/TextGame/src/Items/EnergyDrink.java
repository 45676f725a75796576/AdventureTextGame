package Items;

public class EnergyDrink extends Item{
    public EnergyDrink()
    {
        name = "energy_drink";
        itemImagePath = "src/ImagesOfItems/energyDrink.png";
    }
}
