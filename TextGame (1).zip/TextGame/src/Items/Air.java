package Items;

public class Air extends Item {
    public Air(){
        name = "air";
        itemImagePath = "src/ImagesOfItems/air.png";
    }
}
