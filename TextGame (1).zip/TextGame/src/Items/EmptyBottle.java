package Items;

public class EmptyBottle extends Item{
    public EmptyBottle()
    {
        name = "empty_bottle";
        itemImagePath = "src/ImagesOfItems/emptyBottle.png";
    }
}
