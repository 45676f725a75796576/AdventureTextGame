package Items;

public class Peach extends Item{
    public Peach(){
        name = "peach";
        itemImagePath = "src/ImagesOfItems/peach.png";
    }
}
