package Items;

public class Bread extends Item{
    public Bread(){
        name = "bread";
        itemImagePath = "src/ImagesOfItems/bread.png";
    }
}
