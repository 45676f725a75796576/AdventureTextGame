package Items;

public class Money extends Item {
    public Money(){
        name = "money";
        itemImagePath = "src/ImagesOfItems/money.png";
    }
}
