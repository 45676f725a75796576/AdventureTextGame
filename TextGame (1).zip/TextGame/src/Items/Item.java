package Items;

public class Item {
    protected String name = null;
    protected String itemImagePath = null;

    public String getItemImagePath(){
        return itemImagePath;
    }
}
