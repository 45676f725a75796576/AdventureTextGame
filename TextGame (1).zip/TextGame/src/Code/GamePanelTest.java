package Code;

import static org.junit.jupiter.api.Assertions.*;

class GamePanelTest {

    @org.junit.jupiter.api.Test
    void paintComponent() {
        assertEquals(1,1);
    }

    @org.junit.jupiter.api.Test
    void setCurrentLocationInfo() {
        assertEquals(1,1);
    }

    @org.junit.jupiter.api.Test
    void setProcedures() {
        assertEquals(1,1);
    }

    @org.junit.jupiter.api.Test
    void getGame() {
        assertEquals(1,1);
    }

    @org.junit.jupiter.api.Test
    void updateCurrentLocationInfo() {
        assertEquals(1,1);
    }
}