package Procedures;

public interface Procedure<T> {
    public String initialize(T object);
}
